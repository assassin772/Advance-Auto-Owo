# Advance-Auto-Owo
A Epic OwO Bot Selfbot, which can bypass ban by solving any captcha [ web or imagetotext ]

## Features
- [x] Auto Hunt
- [x] Auto Battle
- [x] Auto Pray
- [x] Auto Level Up 
- [x] Auto Daily
- [x] Auto Sell
- [x] Auto Slot
- [x] Auto CoinFlip
- [x] Auto Use OwO Commands
- [x] Auto Cookie
- [x] Auto HuntBot
- [x] Multiple Channel Support With Custom Time
- [x] Auto Captcha Solve ( uses captcha solvers )
- [x] Webhook Notifier ( about captcha , funds,        dailies, huntbot)
- [x] Logging [ OwOCash, Dailies, captcha solves,   
  webhooks Etc]
<details>
  <summary>Captcha Solvers</summary>


  1. [2Captcha](https://2captcha.com/?from=17257577)
  <br>
  
  2. [CapSolver](https://dashboard.capsolver.com/passport/register?inviteCode=XxmebTqf6O8S)
  <br>
  
  3. [CaptchaAi](https://captchaai.com/?from=80668)
  <br>
  
  4. [CapMonster](https://captchaai.com/?from=80668)
  <br>
  
  5. [Scrappey](https://scrappey.com)
   <br>
</details>

## Todo
- [ ] Auto Use Gems
- [ ] AutoLootboxes
## Recommendation
- [x] Host Privately ( as it has token stored in json file on public host anyone can access it )
- [x] Run In A Alt Account ( as sb against discord tos )
- [x] Use The Account In single srvr ( having multiple servers the script may get conflict by detecting others user captchas )
- [x] Use A Well Level up acc for more profit ( battle team with good weapons and gems )
- [x] Pay Attention To Webhook Logs
- [x] Join Our Community For Support
- [x] [ Axe NukerZ ]( https://discord.gg/x5BKQR4bHt)

### Preview
![Screenshot_20240621-092529~2](https://github.com/TheAxes/Advance-Auto-Owo/assets/110020190/baba0971-c37f-417a-9b6d-67012b1dd9b9)

### How To Use?
Step1:
```
git clone https://github.com/TheAxes/Advance-Auto-Owo.git
```

Step2:
```
cd Advance-Auto-Owo
```
step3:
```
change settings in config.json
```
step4:
```
pip install -r requirements.txt
```
step5
```
python main.py
```
### Video Tutorial
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/CvS5U7pufRg/0.jpg)](https://www.youtube.com/watch?v=CvS5U7pufRg)

[guns.lol](https://guns.lol/TheAxes)


Consider Donating Me For Appreciation

### Donate 
Ltc: ```LSpfN7jD67NwE2356mGcXudybxTR6ZHFdY```

want another payment method for donating letme know on discord
